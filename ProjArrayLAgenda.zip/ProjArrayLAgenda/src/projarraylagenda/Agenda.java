
package projarraylagenda;

import java.util.ArrayList;

public class Agenda {
    private ArrayList<Contato> listaDeContatos;

    public Agenda() {
        this.listaDeContatos = new ArrayList<>();
    }

    public ArrayList<Contato> getListaDeContatos() {
        return listaDeContatos;
    }

    public void setListaDeContatos(ArrayList<Contato> listaDeContatos) {
        this.listaDeContatos = listaDeContatos;
    }
    public ArrayList<Contato> pesquisarAniversariantesMes(byte mes){
        ArrayList<Contato> listaAniversariantesMes = new ArrayList<>();
        for (int i = 0; i <listaDeContatos.size(); i++) {
            if(listaDeContatos.get(i).getListaDeData().get(i).getMes()==mes){
            listaAniversariantesMes.add(listaDeContatos.get(i));
            }
        }
        return listaAniversariantesMes;
    }
    public Contato pesquisarContatoNome(String nome){
         Contato  c = null;
         for (int i = 0; i <listaDeContatos.size(); i++) {
             if (this.listaDeContatos.get(i).getNome().equalsIgnoreCase(nome)){
                 c = this.listaDeContatos.get(i);
             }
        }
         return c;
    }
    
    
}
