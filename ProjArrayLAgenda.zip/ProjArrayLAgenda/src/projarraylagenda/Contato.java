
package projarraylagenda;

import java.util.ArrayList;

public class Contato {
    private String nome;
    private String fone;

    private ArrayList<Data> listaDeData;
    
    public Contato() {
        this.listaDeData = new ArrayList<>();
    }

    public ArrayList<Data> getListaDeData() {
        return listaDeData;
    }

    public void setListaDeData(ArrayList<Data> listaDeData) {
        this.listaDeData = listaDeData;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    @Override
    public String toString() {
        return "listaDeData=" + listaDeData + ", nome=" + nome + ", fone=" + fone + '}';
    }
    
    
    
    
}
