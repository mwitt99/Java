package projarraylagenda;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        Agenda objAgenda = new Agenda();

        byte op;

        do {
            System.out.print("\nEscolha uma opcao");
            System.out.println("\n1 - Cadastrar Contato");
            System.out.println("2 - Listar todos os contatos");
            System.out.println("3 - Mostrar a quantidade de contatos na agenda");
            System.out.println("4 - Pesquisar contato por nome");
            System.out.println("5 - Pesquisar contato por aniversario");
            System.out.println("6 - Exclusao expecifica de um contato");
            System.out.println("0 - Sair");
            System.out.print("Digite aqui a opcao desejada: ");
            op = leia.nextByte();

            switch (op) {
                case 1:
                    Contato objContato = new Contato();
                    System.out.println("Informe os dados do contato");
                    System.out.print("Nome: ");
                    objContato.setNome(leia.next());
                    System.out.print("Fone: ");
                    objContato.setFone(leia.next());
                    
                    objAgenda.getListaDeContatos().add(objContato);
                    break;
                case 2:
                    if(objAgenda.getListaDeContatos().isEmpty()){
                        System.out.println("Nao existem contatos cadastrados");
                    }else{
                        System.out.println(objAgenda);
                    }
                    break;
                case 3:
                    if(objAgenda.getListaDeContatos().isEmpty()){
                        System.out.println("Nao existem contatos cadastrados");
                    }else{
                        System.out.println("A quantidade de contatos é: "+objAgenda.getListaDeContatos().size());
                    }
                    break;
                case 4:
                    System.out.print("Digite o Nome que deseja pesquisar: ");
                    
                    break;
                case 5:
                    System.out.println("Digite o mes do aniversariante que deseja pesquisar: ");
                    byte mes =leia.nextByte();
                    ArrayList<Contato> listaMes = objAgenda.pesquisarAniversariantesMes(mes);
                    if(listaMes.isEmpty()){
                        System.out.println("Nao existem alunos deste mes"+mes);
                    }else{
                        System.out.println("Alunos do mes: "+mes+"\n"+listaMes);
                    }
                    break;
                case 6:
                    
                    break;
                case 0:
                    System.out.println("Sistema Encerrado");
                    break;
                default:
                    System.out.println("Opcao invalida");
            }
        } while (op != 0);
    }
}
