package projassociacao;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        Cliente objCliente = new Cliente();
        Funcionario objFuncionario = new Funcionario();

        System.out.println("Informe os dados do cliente: ");
        System.out.print("Nome: ");
        objCliente.setNome(leia.next());
        System.out.print("CPF: ");
        objCliente.setCpf(leia.nextLong());
        System.out.println("Informe o endereço: ");
        System.out.print("Rua: ");
        objCliente.getEndereco().setRua(leia.next());
        System.out.print("Numero: ");
        objCliente.getEndereco().setNumero(leia.nextInt());
        System.out.print("Complemento: ");
        objCliente.getEndereco().setComplemento(leia.next());
        System.out.println("Bairro: ");
        objCliente.getEndereco().setBairro(leia.next());
        System.out.println("CEP: ");
        objCliente.getEndereco().setCep(leia.next());
        System.out.println("Cidade: ");
        objCliente.getEndereco().setCidade(leia.next());
        System.out.println("Estado: ");
        objCliente.getEndereco().setUf(leia.next());

        System.out.println("Informe os dados do funcionario: ");
        System.out.print("Nome: ");
        objFuncionario.setNome(leia.next());
        System.out.print("CPF: ");
        objFuncionario.setCpf(leia.nextLong());
        System.out.println("Informe o endereço: ");
        System.out.print("Rua: ");
        objFuncionario.getEndereco().setRua(leia.next());
        System.out.print("Numero: ");
        objFuncionario.getEndereco().setNumero(leia.nextInt());
        System.out.print("Complemento: ");
        objFuncionario.getEndereco().setComplemento(leia.next());
        System.out.println("Bairro: ");
        objFuncionario.getEndereco().setBairro(leia.next());
        System.out.println("CEP: ");
        objFuncionario.getEndereco().setCep(leia.next());
        System.out.println("Cidade: ");
        objFuncionario.getEndereco().setCidade(leia.next());
        System.out.println("Estado: ");
        objFuncionario.getEndereco().setUf(leia.next());

        System.out.println("Dados do Funcionario: ");
        System.out.println(objFuncionario);

    }

}
