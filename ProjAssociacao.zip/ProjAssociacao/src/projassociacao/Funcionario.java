
package projassociacao;
public class Funcionario {
    private String nome;
    private long cpf;
    private int chapa;
    private double salario;
    private Endereco endereco;

    public Funcionario() {
        this.endereco = new Endereco();
    }
    
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getChapa() {
        return chapa;
    }

    public void setChapa(int chapa) {
        this.chapa = chapa;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "\nNome: " + nome +
               "\nCPF: " + cpf + 
               "Chapa: " + chapa + 
               "\nSalario: " + salario + 
               "\nEndereco Funcionário" + endereco;
    }
    
    
}
