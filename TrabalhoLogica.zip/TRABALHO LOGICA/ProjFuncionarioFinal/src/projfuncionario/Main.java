package projfuncionario;//Pacote do projeto.

import java.util.Scanner;//importacao da funcao scanner.

public class Main {//Classe principal

    public static void main(String[] args) {//metodo main
        Scanner leia = new Scanner(System.in);//Criaçao e instanciamento do objeto.
        String nome;//Declaração de Atributo.
        String CPF;//Declaração de Atributo.
        String RG;//Declaração de Atributo.
        String endereco;//Declaração de Atributo.
        String fone;//Declaração de Atributo.
        String sexo = null;//Declaração de Atributo.
        String email;//Declaração de Atributo.
        int qtdDependentes;//Declaração de Atributo.
        int chapa;//Declaração de Atributo.
        String cargo;//Declaração de Atributo.
        int tempodDeServicoAno;//Declaração de Atributo.
        double valorHora;//Declaração de Atributo.
        double cargaHorariaBase;//Declaração de Atributo.
        double qtdHorasExtras;//Declaração de Atributo.
        byte opcaoVT;//Declaração de Atributo.
        double valorTotalDaPassagem ;//Declaração de Atributo.
        byte grauInsalubridade;//Declaração de Atributo.
        byte op2;//Declaração de Atributo.
        byte op;//Declaração de Atributo.

        do {//laço de repeticao do.
            System.out.println("*** Cadastro Funcionario ***");//mostra tela.
            System.out.print("Nome: ");//mostra tela.
            nome = leia.next();//o leia.
            System.out.print("CPF: ");//mostra tela.
            CPF = leia.next();//o leia.
            System.out.print("RG: ");//mostra tela.
            RG = leia.next();//o leia.
            System.out.print("Endereço: ");//mostra tela.
            endereco = leia.next();//o leia.
            System.out.print("Fone: ");//mostra tela.
            fone = leia.next();//o leia.
            System.out.println("");

            do {//laço de repeticao do.
                System.out.println("Escolha seu sexo: ");//mostra tela.
                System.out.println("[1] Masculino");//mostra tela.
                System.out.println("[2] Feminino");//mostra tela.
                System.out.print("Digite sua opção: ");//mostra tela.
                op = leia.nextByte();//o leia
                switch (op) {//switch
                    case 1:
                        sexo = "Masculino";
                        break;
                    case 2:
                        sexo = "Feminino";
                        break;
                }
            } while (op != 1 && op != 2);//chave final do do while.

            System.out.println("");
            System.out.print("E-mail: ");//mostra tela.
            email = leia.next();//o leia.
            System.out.print("Qtd de dependentes: ");//mostra tela.
            qtdDependentes = leia.nextByte();//o leia.
            System.out.print("Chapa: ");//mostra tela.
            chapa = leia.nextByte();//o leia.
            System.out.print("Cargo: ");//mostra tela.
            cargo = leia.next();//o leia.
            System.out.print("Tempo de serviço: ");//mostra tela.
            tempodDeServicoAno = leia.nextByte();//o leia.
            System.out.print("Valor Hora: R$");//mostra tela.
            valorHora = leia.nextDouble();//o leia.
            System.out.print("Carga Horaria Base: ");//mostra tela.
            cargaHorariaBase = leia.nextDouble();//o leia.
            System.out.println("");

            Funcionario objFun = new Funcionario(nome, CPF, endereco, fone, chapa, valorHora);//criaçao do objeto

            do {//laço de repeticao do.
                System.out.println("Escolha do Vale Transporte: ");//mostra tela.
                System.out.println("[1] Sim, ganha VT");//mostra tela.
                System.out.println("[2] Não, não ganha VT");//mostra tela.
                System.out.print("Digite sua opção: ");//mostra tela.
                op = leia.nextByte();//o leia.
                switch (op) {//switch
                    case 1://caso 1
                        objFun.receberVT();//
                        System.out.println("Valor total da passagem");//mostra tela.
                        valorTotalDaPassagem = leia.nextDouble();//o leia.
                        objFun.setValorTotalDaPassagem(valorTotalDaPassagem);//setando o valorTotalDaPassagem.
                        break;//parar
                    case 2://caso 2
                        objFun.cancelarVT();//objFun.cancelarVT().
                        break;//parar
                    default://default
                        System.out.println("Invalid");//mostra tela.
                }//final do switch
            } while (op != 1 && op != 2);//chave final do do while.

            System.out.print("Quantidade de horas extras: ");//mostra tela.
            qtdHorasExtras = leia.nextDouble();//o leia.
            do {//laço de repeticao do.
                System.out.println("Taxa de Insalubridade");//mostra tela.
                System.out.println("[1] Maxímo");//mostra tela.
                System.out.println("[2] Médio");//mostra tela.
                System.out.println("[3] Mínimo");//mostra tela.
                System.out.println("[0] Não recebe insalubridade");//mostra tela.
                System.out.print("Digite sua opção: ");//mostra tela.
                grauInsalubridade = leia.nextByte();//o leia.

                switch (op) {
                    case 1:
                        objFun.setGrauInsalubridade(grauInsalubridade);
                        break;
                    case 2:
                        objFun.setGrauInsalubridade(grauInsalubridade);
                        break;
                    case 3:
                        objFun.setGrauInsalubridade(grauInsalubridade);
                        break;
                    default:
                        System.out.println("Invalido");
                }
            } while (op != 1 && op != 2 && op != 3 && op != 0);//while
            
            
            objFun.setGrauInsalubridade(grauInsalubridade);
            objFun.setEmail(email);//sets
            objFun.setRG(RG);//sets
            objFun.setQtdDependentes(qtdDependentes);//sets
            objFun.setCargo(cargo);//sets
            objFun.setTempodDeServicoAno(tempodDeServicoAno);//sets
            objFun.setSexo(sexo);//sets
            objFun.setQtdHorasExtras(qtdHorasExtras);//sets
            objFun.setCargaHorariaBase(cargaHorariaBase);//sets

            System.out.println("");
            do {//laço de repeticao do.
                System.out.println("*** Dados do Funcionario ***");//mostra tela.
                System.out.println("[1] Mostrar nome e Salário Bruto");//mostra tela.
                System.out.println("[2] Mostrar nome e Valor de horas extras");//mostra tela.
                System.out.println("[3] Mostrar nome e Valor do VT");//mostra tela.
                System.out.println("[4] Mostrar nome e Valor do INSS");//mostra tela.
                System.out.println("[5] Mostrar nome e Valor da Insalubridade");//mostra tela.
                System.out.println("[6] Mostrar nome e Valor  do Salário Família");//mostra tela.
                System.out.println("[7] Mostrar nome e Valor do plano de carreira");//mostra tela.
                System.out.println("[8] Mostrar nome e Valor  total de plano de saúde");//mostra tela.
                System.out.println("[9] Mostrar nome e Valor do Salário Líquido");//mostra tela.
                System.out.println("[10] Mostrar todos os dados e cálculos de funcionário");//mostra tela.
                System.out.println("[11] Cadastrar novo funcionário");//mostra tela.
                System.out.println("[0] Sair do sistema");//mostra tela.
                System.out.print("Digite aqui sua opção: ");//mostra tela.
                op = leia.nextByte();//o leia.
                System.out.println("");

                switch (op) {//switch
                    case 1://caso 1
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Salario Bruto: " + objFun.calcularSalarioBruto());//mostra tela.
                        System.out.println("");
                        break;//parar
                    case 2://caso 2
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor de horas extra: " + objFun.calcularHoraExtra());//mostra tela.          
                        System.out.println("");
                        break;//parar
                    case 3://caso 3
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor VT: " + objFun.calcularVT());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 4://caso 4
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor do INSS: " + objFun.calcularINSS());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 5://caso 5
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor da Insalubridade: " + objFun.calcularInsalubridade());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 6://caso 6
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor  do Salário Família: R$%.2f" + objFun.calcularSalarioFamilia());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 7://caso 7
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor do plano de carreira: " + objFun.calcularPlanoDeCarreira());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 8://caso 8
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor  total de plano de saúde: " + objFun.calcularPlanoDeSaude());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 9://caso 9
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Nome Funcionario: " + objFun.getNome());//mostra tela.
                        System.out.println("Valor do Salário Líquido: " + objFun.calcularSalarioLiquido());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 10://caso 10
                        System.out.println("*** Dados Requeridos ***");//mostra tela
                        System.out.println(objFun);//mostra tela.
                        System.out.println("Taxa VT: " + objFun.mostrarLegenda());//mostra tela.
                        System.out.println("\nSalario Bruto: " + objFun.calcularSalarioBruto());//mostra tela.
                        System.out.println("\nValor de horas extras: " + objFun.calcularHoraExtra());//mostra tela.
                        System.out.println("Valor VT: " + objFun.calcularVT());//mostra tela.
                        System.out.println("\nValor do INSS: " + objFun.calcularINSS());//mostra tela.
                        System.out.println("\nValor da Insalubridade: " + objFun.calcularInsalubridade());//mostra tela.
                        System.out.println("\nValor do Salário Família: " + objFun.calcularSalarioFamilia());//mostra tela.
                        System.out.println("\nValor do plano de carreira: " + objFun.calcularPlanoDeCarreira());//mostra tela.
                        System.out.println("\nValor total de plano de saúde: " + objFun.calcularPlanoDeSaude());//mostra tela.
                        System.out.println("\nValor do Salário Líquido: " + objFun.calcularSalarioLiquido());//mostra tela.
                        System.out.println("\n");
                        break;//parar
                    case 11://caso 11
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Novo cadastro INICIALIZADO");//mostra tela.
                        System.out.println("");
                        break;//parar
                    case 0://caso 0
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("Sistema Encerrado");//mostra tela.
                        System.out.println("");
                        break;//parar
                    default://default
                        System.out.println("*** Dados Requeridos ***");//mostra tela.
                        System.out.println("opcao invalida");//mostra tela.
                }//final do switch.   
            } while (op != 0 && op != 11);//chave final do do while.
            op2 = op;//op2 recebe op.
        } while (op2 == 11);//chave final do do while.
    }//chave final do metodo main.
}//Chave final do main.
