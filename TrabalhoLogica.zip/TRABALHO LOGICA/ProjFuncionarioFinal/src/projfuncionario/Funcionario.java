package projfuncionario;//Pacote onde esta o projeto salvo.
//Linha em branco para organização
public class Funcionario {//É o comeco da classe.
//Linha em branco para organização
    private String nome;//Declaração dos Atributos.
    private String CPF;//Declaração dos Atributos.
    private String RG;//Declaração dos Atributos.
    private String endereco;//Declaração dos Atributos.
    private String fone;//Declaração dos Atributos.
    private String sexo;//Declaração dos Atributos.
    private String email;//Declaração dos Atributos.
    private int qtdDependentes;//Declaração dos Atributos.
    private int chapa;////Declaração dos Atributos.
    private String cargo;////Declaração dos Atributos.
    private int tempodDeServicoAno;//Declaração dos Atributos.
    private double valorHora;//Declaração dos Atributos.
    private double cargaHorariaBase;//Declaração dos Atributos.
    private double qtdHorasExtras;//Declaração dos Atributos.
    private boolean opcaoVT;//Declaração dos Atributos.
    private double valorTotalDaPassagem;//Declaração dos Atributos.
    private byte grauInsalubridade;//Declaração dos Atributos.
//Linha em branco para organização
      public Funcionario(String nome, String CPF, String endereco, String fone, int chapa, double valorHora) {//metodo construtor.
        this.nome = nome;//Atributos que estao dentro do metodo construtor.
        this.CPF= CPF;//Atributos que estao dentro do metodo construtor.
        this.endereco = endereco;//Atributos que estao dentro do metodo construtor.
        this.fone = fone;//Atributos que estao dentro do metodo construtor.
        this.chapa = chapa;//Atributos que estao dentro do metodo construtor.
        this.valorHora = valorHora; //Atributos que estao dentro do metodo construtor.
        }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getNome() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele. 
        return nome;//retorna nome.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setNome(String nome) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.nome = nome;//nome recebe nome.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getCPF() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return CPF;//retorna cpf.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setCPF(String CPF) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.CPF = CPF;//cpf recebe cpf.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getRG() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return RG;//retorna rg.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setRG(String RG) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.RG = RG;//rg recebe rg.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getEndereco() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return endereco;//retorna endereco.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setEndereco(String endereco) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.endereco = endereco;//enderco recebe endereco.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getFone() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return fone;//retorna fone.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setFone(String fone) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.fone = fone;//fone recebe fone.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getSexo() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return sexo;//retorna sexo.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setSexo(String sexo) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.sexo = sexo;//sexo recebe sexo.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getEmail() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return email;//retorna email.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setEmail(String email) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.email = email;//email recebe email.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public int getQtdDependentes() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return qtdDependentes;//retorna qtdDependentes.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setQtdDependentes(int qtdDependentes) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.qtdDependentes = qtdDependentes;//qtdDePendentes recebe qtdDependentes.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public int getChapa() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return chapa;//retorna chapa.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setChapa(int chapa) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.chapa = chapa;//chapa recebe chapa.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String getCargo() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return cargo;//retorna cargo.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setCargo(String cargo) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.cargo = cargo;//cargo recebe cargo.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public int getTempodDeServicoAno() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return tempodDeServicoAno;//retorna  tempodDeServicoAno.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setTempodDeServicoAno(int tempodDeServicoAno) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.tempodDeServicoAno = tempodDeServicoAno;//tempodDeServicoAno recebe tempodDeServicoAno. 
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double getValorHora() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return valorHora;//retorna valorHora.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setValorHora(double valorHora) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.valorHora = valorHora;//valorHora recebe valorHora.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double getCargaHorariaBase() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return cargaHorariaBase;//retorna cargaHorariaBase.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setCargaHorariaBase(double cargaHorariaBase) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.cargaHorariaBase = cargaHorariaBase;//cargaHorariaBase recebe cargaHorariaBase.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double getQtdHorasExtras() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return qtdHorasExtras;//retorna quantidade de horas extras.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setQtdHorasExtras(double qtdHorasExtras) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.qtdHorasExtras = qtdHorasExtras;
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public boolean isOpcaoVT() {//Metodo isopcaoVT.
        return opcaoVT;//retorna opcaoVt.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setOpcaoVT(boolean opcaoVT) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.opcaoVT = opcaoVT;//opcaoVt recebe opcatVT.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double getValorTotalDaPassagem() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return valorTotalDaPassagem;//retorna valorTotalDaPassagem.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setValorTotalDaPassagem(double valorTotalDaPassagem) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.valorTotalDaPassagem = valorTotalDaPassagem;//valorTotalDaPassagem recebe valorTotalDaPassagem.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public byte getGrauInsalubridade() {//Metodo get.Serve para pegar o parametro que foi para dentro do atributo pegar ele e mostrar no main quando chamarem ele.
        return grauInsalubridade;//retorna grauInsalubridade.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void setGrauInsalubridade(byte grauInsalubridade) {//metodo set.quando o usuario digitar no main para cadastrar um funcionario o parametro com a informação vem pra ca
        this.grauInsalubridade = grauInsalubridade;
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public String mostrarLegenda() {//metodo mostrarLegenda.
        if (opcaoVT) {//Inicio do teste de mostrarLegenda.
            return "Não Recebe Vale Transporte";//retorna nao recebe vale transporte.
        } else {//Senao.
            return "Recebe Vale Transporte";//retorna recebe vale transporte.
        }//final do teste.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void receberVT() {//metodo receberVT.
        this.opcaoVT = true;//opcaoVt recebe true.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public void cancelarVT() {//metodo cancelarVT.
        this.opcaoVT = false;//opcaoVt recebe false.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double calcularHoraExtra() {//metodo calcularHoraExtra.serve para calcular ne a hora extra.
     double valorExtra;//declaraçao do atributo.
        if (this.qtdHorasExtras > 2) {//se qtdHorasExtras maior que 2.
            valorExtra = (this.valorHora * 3);//valorhora recebe o calculo.
            valorExtra += (this.valorHora * 2) * (qtdHorasExtras - 2);//
        } else {//senao
            valorExtra = (this.valorHora * 1.50) * qtdHorasExtras;//valorhora recebe o calculo.
        }//final do if.
        return valorExtra;//retorna valorExtra.
    }//final do metodocalcularHoraExtra.
//Linha em branco para organização
    public double calcularSalarioBruto() {//metodo de calcularSalarioBruto.
        return (this.valorHora * this.cargaHorariaBase)+ calcularHoraExtra();//retorna valorHora vezes cargaHorariaBase.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double calcularVT() {//metodo calcularVT.
       if(opcaoVT){//se opcaoVT.
        if (this.valorTotalDaPassagem > (calcularSalarioBruto() * 0.06)) {
                return calcularSalarioBruto() * 0.06;//retorna calcularSalarioBruto vezes 0.06.
            } else {//senao
                return this.valorTotalDaPassagem;//retorna valorTotalDaPassagem.
       }//final do teste valorTotalDaPassagem.
     }
    return 0;
    }//chave final do metodo calcularVT.
//linha em branco para organizaçao    
//Linha em branco para organização
    public double calcularINSS() {//metodo de calcular o inss.
        if (calcularSalarioBruto() <= 1399.12) {//se calcularSalarioBruto menor ou igual 1399.12.
            return calcularSalarioBruto() * 0.08;//retorna calcularSalarioBruto vezes 0.08.
        } else if (calcularSalarioBruto() >= 1399.13 && calcularSalarioBruto() <= 2331.88) {//senao se calcularSalarioBruto menor ou igual 2331.88.
            return calcularSalarioBruto() * 0.09;//retorna calcularSalarioBruto vezes 0.09.
        } else if (calcularSalarioBruto() >= 2331.89 && calcularSalarioBruto() <= 4663.75) {//senao se calcularSalarioBruto menor ou igual 4663.75.
            return calcularSalarioBruto() * 0.11;//retorna calcularSalariobruto vezes 0.11.
        }else {//senao
            return 513.01;//retorna 513.01.
        }//final do teste do inss.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double calcularInsalubridade() {//metodo calcularInsalubridade.
        switch (this.grauInsalubridade) {//comeco do switch.
            case 1://caso o usuario digitar 1.
                return 868 * 0.40;//retorna 868 * 0.40.
            case 2://caso o usuario digitar 2.
                return 868 * 0.20;//retorna 868 * 0.20.
            case 3://caso o usuario digitar 3.
                return 868 * 0.10;//retorna 868 *0.10.
        }//chave final do switch.
        return 0;//retorna 0.
    }//Final do metodo calcularInsalubridade.
 //Linha em branco para organização
//Linha em branco para organização
    public double calcularSalarioFamilia() {//Metodo calcularSalarioFamilia.
        if (qtdDependentes == 1) {//senao se quantidade dependentes igual 1.
            return calcularSalarioBruto() * 0.02;//retorna calcularSalarioBruto vezes 0.02.
        } else if (qtdDependentes <= 3) {//Senao se quantidade dependentes igual 3.
            return calcularSalarioBruto() * 0.04;//retorna calcularSalarioBruto vezes 0.04.
        } else if(qtdDependentes > 3){
            return calcularSalarioBruto() * 0.05;//retorna calcularSalarioBruto vezes 0.05.
        }//Final do teste dos dependentes.
        return 0;//retorna 0.
    }//Chave final do metodo calcularSalarioFamilia.
//Linha em branco para organização
//Linha em branco para organização
//Linha em branco para organização
    public double calcularPlanoDeCarreira() {//metodo calcularPlanoDeCarreira
        //Carreira recebe o tempo de servico ano dividido por 3.
        return (tempodDeServicoAno/3) * 0.05 * calcularSalarioBruto();//Esta retornando o calculo do plano de carreira.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double calcularPlanoDeSaude() {//Metodo calcularPlanoDeSaude.
       return calcularSalarioBruto()*0.005+(calcularSalarioBruto()*(this.qtdDependentes/100));//retorna o calculo.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    public double calcularSalarioLiquido() {//Metodo calcularSalarioLiquido.
        return calcularSalarioBruto() + calcularInsalubridade() - calcularVT() - calcularPlanoDeSaude() - calcularINSS() + calcularPlanoDeCarreira() + calcularSalarioFamilia();//Esta retornando o calculo do salario liquido.
    }//Chave para dizer o final do metodo .
//Linha em branco para organização
    @Override//Ancestral
    public String toString() {//toString.Metodo que mostra todas informações da classe Funcionario.
        return "Nome: " + nome + "\n"//Esta retornando o nome.
                + "CPF: " + CPF + "\n"//Esta retornando o cpf.
                + "RG:" + RG + "\n"//Esta retornando o rg
                + "Endereco: " + endereco + "\n"//Esta retornando o endereco.
                + "Fone: " + fone + "\n"//Esta retornando o fone.
                + "Sexo: " + sexo + "\n"//Esta retornando o sexo.
                + "E-mail: " + email + "\n"//Esta retornando o email.
                + "Qtd Dependentes: " + qtdDependentes + "\n"//Esta retornando a quantidade de dependentes.
                + "Chapa: " + chapa + "\n"//Esta retornando a chapa.
                + "Cargo:" + cargo + "\n"//Esta retornando o cargo. 
                + "Tempo de Servico Ano: " + tempodDeServicoAno + "\n"//Esta retornando o tempo de servico ano.
                + "ValorHora: " + valorHora + "\n"//Esta retornando o valor hora. 
                + "Carga horaria Base: " + cargaHorariaBase + "\n"//Esta retornando o carga horaria base.
                + "Qtd Horas Extras: " + qtdHorasExtras + "\n"//Esta retornando o total de horas extras.
                + "Valor Total da Passagem: " + valorTotalDaPassagem + "\n"//Esta retornando o valor total da passagem.
                + "Grau Insalubridade: " + grauInsalubridade;//Esta retornando o grau de insalubridade.
    }//Chave indicando fim do toString.
}//Chave indicando final da classe Funcionario.
