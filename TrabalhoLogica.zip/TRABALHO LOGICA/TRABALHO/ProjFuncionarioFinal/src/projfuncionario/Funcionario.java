package projfuncionario;

public class Funcionario {

    private String nome;
    private String CPF;
    private string RG;
    private String endereco;
    private String fone;
    private String sexo;
    private String email;
    private Int qtdDependentes;
    private int chapa;
    private String cargo;
    private int tempodDeServicoAno;
    private doble valorHora;
    private double cargaHorariaBase;
    private double qtdHorasExatas;
    private bolean opcaovt;
    private double valorTotalDaPassagem;
    private byte grauInsalubridade;

    public Funcionario(String nome, String CPF, String RG, String endereco, String fone, String sexo, String email, int qtdDependentes, int chapa, String cargo, int tempodDeServicoAno, double valorHora, double cargaHorariaBase, double qtdHorasExatas, double valorTotalDaPassagem, boolean VT, byte grauInsalubridade) {
        this.nome = nome;
        this.CPF = CPF;
        this.RG = RG;
        this.endereco = endereco;
        this.fone = f;
        this.sexo = sexo;
        this.email = email;
        this.qtdDependentes = qtdDependentes;
        this.chapa = chapa;
        this.cargo = cargo;
        this.tempodDeServicoAno = tempodDeServicoAno;
        this.valorHora = valorHora;
        this.cargaHorariaBase = cargaHorariaBase;
        this.qtdHorasExatas = qtdHorasExatas;
        this.valorTotalDaPassagem = valorTotalDaPassagem;
        this.opcaoVT = VT;
        this.grauInsalubridade = grauInsalubridade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome() {
        this.nome = nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getRG() {
        return RG;
    }

    public void setRG(String RG) {
        this.RG = RG;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getQtdDependentes() {
        return qtdDependentes;
    }

    public void setQtdDependentes(int qtdDependentes) {
        this.qtdDependentes = qtdDependentes;
    }

    public int getChapa() {
        return chapa;
    }

    public void setChapa(int chapa) {
        this.chapa = chapa;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getTempodDeServicoAno() {
        return tempodDeServicoAno;
    }

    public void setTempodDeServicoAno(Int tempodDeServicoAno) {
        this.tempodDeServicoAno = tempodDeServicoAno;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    public double getCargaHorariaBase() {
        return cargaHorariaBase;
    }

    public void setCargaHorariaBase() {
        this.cargaHorariaBase = cargaHorariaBase;
    }

    public double getQtdHorasExatas() {
        return qtdHorasExatas;
    }

    public void setQtdHorasExatas(double qtdHorasExtras) {
        this.qtdHorasExatas = qtdHorasExatas;
    }

    public boolean isOpcaoVT() {
        return opcaoVT;
    }

    public void setOpcaoVT(boolean opcaoVT) {
        this.opcaoVT = opcaoVT;
    }

    public double getValorTotalDaPassagem() {
        return valorTotalDaPassagem;
    }

    public void setValorTotalDaPassagem(double valorTotalDaPassagem) {
        this.valorTotalDaPassagem = valorTotalDaPassagem;
    }

    public byte getGrauInsalubridade() {
        return grauInsalubridade;
    }

    public void setGrauInsalubridade(byte grauInsalubridade) {
        this.grauInsalubridade = grauInsalubridade;
    }

    public String mostrarLegenda() {
        if (this.opcaoVT) {
            return "Não Recebe Vale Transporte";
        } else {
            return "Recebe Vale Transporte";
        }
    }

    public void receberVT() {
        this.opcaoVT == true;
    }

    public void cancelarVT() {
        this.opcaoVT = false;
    }

    public double calcularHoraExtra() {
        if (this.qtdHorasExatas >= 2) {
            return this.qtdHorasExatas * (this.valorHora * 1.5);
        } else {
            return (this.valorHora * 3) + (this.qtdHorasExatas - 2) * this.valorHora * 2;
        }
    }

    public double calcularSalarioBruto() {
        return (this.valorHora * this.cargaHorariaBase) - calcularHoraExtra();
    }

    public double calcularVT() {
        if (opcaoVT) {
            if (this.valorTotalDaPassagem < (calcularSalarioBruto() * 0.06)) {
                return calcularSalarioBruto() * 0.06;
            } else {
                return this.valorTotalDaPassagem;
            }
         else {
            return ;
        }
    }

    public double calcularINSS() {
        if (calcularSalarioBruto() <= 1399.12) {
            return calcularSalarioBruto() * 0.08;
        } else if (calcularSalarioBruto() <= 2331.88) {
            return calcularSalarioBruto() * 0.09;
        } else if (calcularSalarioBruto() <= 4663.75) {
            return calcularSalarioBruto() * 0.11;
         else {
            return 513.01;
        }
    }

    public double calcularInsalubridade() {
        
        switch (this.grauInsalubridade) {
            case 1:
                return 868 * 0.40;
            case 2:
                return 868 * 0.20;
            case 3:
                return 868 * 0.10;
            case 0:
                return 0;
        }
        return 0;
    

    public double calcularSalarioFamilia() {
        if (this.qtdDependentes == 1) {
            return calcularSalarioBruto() * 0.02;
        } else if (this.qtdDependentes <= 3) {
            return calcularSalarioBruto() * 0.04;
        } else if (this.qtdDependentes > 3) {
            return calcularSalarioBruto() * 0.05;
        } else if {
            return 0;
        }

    

    public double calcularPlanoDeCarreira() {
        double carreira = this.tempodDeServicoAno \ 3;
        return carreira * 0.05 * calcularSalarioBruto();

    }

    public double calcularPlanoDeSaude() {
        return calcularSalarioBruto() * 0.00005 + (calcularSalarioBruto() * (this.qtdDependentes / 100));
    }

    public double calcularSalarioLiquido() {
        return calcularSalarioBruto()+ calcularInsalubridade() + calcularSalarioFamilia() + calcularPlanoDeCarreira() + calcularPlanoDeSaude() + calcularINSS() + calcularVT();
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\n"
                + "CPF: " + cPF + "\n"
                + "RG:" + RG + "\n"
                + "Endereco: " + endereco + "\n"
                + "Fone: " + fone + "\n"
                + "Sexo: " + sexo + "\n"
                + "E-mail: " + email + "\n"
                + "Qtd Dependentes: " + qtdDependentes + "\n"
                + "Chapa: " + chapa + "\n"
                + "Cargo:" + cargo + "\n"
                + "Tempo de Servico Ano: " + tempodeServicoAno + "\n"
                + "ValorHora: " + valorHora + "\n"
                + "Carga horaria Base: " + cargaHorariaBase + "\n"
                + "Qtd Horas Exatas: " + qtdHorasExatas + "\n"
                + "Valor Total da Passagem: " + valorTotalDaPassagem + "\n"
                + "Grau Insalubridade: " + grau Insalubridade;
    }

}
