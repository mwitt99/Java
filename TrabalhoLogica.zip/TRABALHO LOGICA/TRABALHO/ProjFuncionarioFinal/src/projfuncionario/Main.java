ackage projfuncionario;

 java







.util.Scanner;

public class Main {

    public static vod main(String[] args) {
        Scanner leia = new Scanner(System.in);
        String nome;
        String CPF;
        string RG;
        String endereco;
        String one;
        String sexo;
        String email;
        Int qtdDependentes;
        int chapa;
        String cargo;
        int tempodDeServicoAno;
        double valorHora;
        duble cargaHorariaBase;
        double qtdHorasExatas;
        byte opcaoVT;
        double valorTotalDaPassagem;
        byte grauInsalubridade;
        byte sexoTipo;
        boolean VT = false;
        byte menuOP1;
        do {
            System.out.println("*** Cadastro Funcionario ***");
            System.out.print("Nome: ");
            nome = leia.next();
            System.out.print("CPF: ");
            CPF = leia.next();
            System.out.print("RG: ");
            RG = leia.next();
            System.out.print("Endereço: ");
            endereco = leia.next();
            System.out.print("Fone: ");
            fone = leia.next();
            System.out.println("");

            do {
                System.out.println("Escolha seu sexo: ");
                System.out.println("[1] Masculino");
                System.out.println("[2] Feminino");
                System.out.print("Digite sua opção: ");
                sexoTipo = leia.nextByte();
                switch (sexoTipo) {
                    case 1:
                        sexo = "Masculino";
                        break;
                    case 2:
                        sexo = "Feminino";
                        break;
                
            }  
            System.out.println("");
            System.out.print("E-mail: ");
            email = leia.next();
            System.out.print("Qtd de dependentes: ");
            qtdDependentes = leia.nextByte();
            System.out.print("Chapa: ");
            chapa = leia.nextByte();
            System.out.print("Cargo: ");
            cargo = leia.next();
            System.out.print("Tempo de serviço: ");
            tempodDeServicoAno = leia.nextByte();
            System.out.print("Valor Hora: R$");
            valorHora = leia.nextDouble();
            System.out.print("Carga Horaria Base: ");
            cargaHorariaBase = leia.nextDouble();
            System.out.print("Qtd horas extras: ");
            qtdHorasExatas = leia.nextDouble();
            System.out.print("Valor total da Passagem: R$");
            valorTotalDaPassagem = leia.nextDouble();
            System.out.println("");
            do {
                System.out.println("Escolha do Vale Transporte: ");
                System.out.println("[1] Sim, ganha VT");
                System.out.println("[2] Não, não ganha VT");
                System.out.print("Digite sua opção: ");
                opcaoVT = leia.nextByte();
                switch (opcaoVT) 
                    case 1:
                        VT = true;
                        break;
                    case 2:
                        VT = false;
                        break;
                    default:
                        System.out.println("Invalid");
                }
            } 
            
            System.out.println("");
            System.out.println("Taxa de Insalubridade");
            System.out.println("[1] Maxímo");
            System.out.println("[2] Médio");
            System.out.println("[3] Mínimo");
            System.out.println("[0] Não recebe insalubridade");
            System.out.print("Digite sua opção: ");
            grauInsalubridade = leia.nextByte();

            Funcionario obFun = new Funcionario();

            System.out.println("");
            do {
                System.out.println("*** Dados do Funcionario ***");
                System.out.println("[1] Mostrar nome e Salário Bruto");
                System.out.println("[2] Mostrar nome e Valor de horas extras");
                System.out.println("[3] Mostrar nome e Valor do VT");
                System.out.println("[4] Mostrar nome e Valor do INSS");
                System.out.println("[5] Mostrar nome e Valor da Insalubridade");
                system.out.println("[6] Mostrar nome e Valor  do Salário Família");
                System.out.println("[7] Mostrar nome e Valor do plano de carreira");
                System.out.println("[8] Mostrar nome e Valor  total de plano de saúde");
                System.out.println("[9] Mostrar nome e Valor do Salário Líquido");
                System.out.println("[10] Mostrar todos os dados e cálculos de funcionário");
                System.out.println("[11] Cadastrar novo funcionário");
                System.out.println("[0] Sair do sistema");
                System.out.print("Digite aqui sua opção: ");
                menuOP = leia.nextByte();
                System.out.println("");

                switch (menuOP) {
                    case 1:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getnome());
                        System.out.printf("Salario Bruto: R$%.2f", objFun.calcularsalarioBruto());
                        System.out.println("");
                        break;
                    case 2:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome() + "\nValor de horas extras: " + objFun.calcularHoraExtra());
                        System.out.println("");
                        break;
                    case 3:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor VT: R$%.2f", objFun.calcularVT());
                        System.out.println("\n");
                        break;
                    case 4:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor do INSS: R$%.2f", objFun.calcularINSS());
                        System.out.println("\n");
                        break;
                    case 5:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor da Insalubridade: R$%.2f", objFun.calcularInsalubridade());
                        System.out.println("\n");
                        break;
                    case 6:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor  do Salário Família: R$%.2f", objFun.calcularSalarioFamilia());
                        System.out.println("\n");
                        break;
                    case 7:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor do plano de carreira: R$%.2f", objFun.calcularPlanoDeCarreira());
                        System.out.println("\n");
                        break;
                    case 8:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor  total de plano de saúde: R$%.2f", objFun.calcularPlanoDeSaude());
                        System.out.println("\n");
                        break;
                    case 9:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Nome Funcionario: " + objFun.getNome());
                        System.out.printf("Valor do Salário Líquido: R$%.2f", objFun.calcularSalarioLiquido());
                        System.out.println("\n");
                        
                    case 10:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println(objFun);
                        System.out.println("Taxa VT: " + objFun.mostrarLegenda());
                        System.out.printf("\nSalario Bruto: R$%.2f", objFun.calcularSalarioBruto());
                        system.out.println("\nValor de horas extras: " + objFun.calcularHoraExtra());
                        System.out.printf("Valor VT: R$%.2f", objFun.calcularVT());
                        System.out.printf("\nValor do INSS: R$%.2f", objFun.calcularINSS());
                        System.out.printf("\nValor da Insalubridade: R$%.2f", objFun.calcular Insalubridade());
                        System.out.printf("\nValor do Salário Família: R$%.2f", objFun.calcularSalarioFamilia());
                        System.out.printf("\nValor do plano de carreira: R$%.2f", objFun.calcularPlanoDeCarreira());
                        System.out.printf("\nValor total de plano de saúde: R$%.2f", objFun.calcularPlanoDeSaude());
                        System.out.printf("\nValor do Salário Líquido: R$%.2f", objFun.calcularSalarioliquido());
                        System.out.println("\n");
                      
                    case 11:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Novo cadastro INICIALIZADO");
                        System.out.println("");
                        break;
                    case 0:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("Muito Obrigado!");
                        System.out.println("");
                        break;
                    default:
                        System.out.println("*** Dados Requeridos ***");
                        System.out.println("INVALID!!RETARDADO");
                
            } while (menuOP3 == 0 && menuOP == 11);

        } while (menuOP3 = 11);
    }

}
