package mediaaritmetica;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class MediaAritmetica {
    public static void main(String[] args) {
        double nota1;
        double nota2;
        double nota3;
        double nota4;
        double media;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Digite a nota do 1º bimestre");
        nota1 = scan.nextDouble();
        System.out.println("Digite a nota do 2º bimestre");
        nota2 = scan.nextDouble();
        System.out.println("Digite a nota do 3º bimestre");
        nota3 = scan.nextDouble();
        System.out.println("Digite a nota do 4º bimestre");
        nota4 = scan.nextDouble();
        
        media = (nota1+nota2+nota3+nota4)/4;
        
        System.out.println("Informacoes dos bimetres");
        System.out.println("1º Bimestre: " + nota1);
        System.out.println("2º Bimestre: " + nota2);
        System.out.println("3º Bimestre: " + nota3);
        System.out.println("4º Bimestre: " + nota4);
        System.out.println("Média: " + media);
    }//fecha main
}//fecha classe
