package calculoimc;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class CalculoImc {
    public static void main(String[] args) {
        double peso;
        double altura;
        double imc;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Informe o seu peso?");
        peso = scan.nextDouble();
        System.out.println("Informe o sua altura?");
        altura = scan.nextDouble();
        
        imc = peso/(altura*altura);
        
        System.out.println("Informações");
        System.out.println("Seu peso: " + peso);
        System.out.println("Sua altura: " + altura);
        System.out.println("Seu IMC: " + imc);
    }//fecha main
}//fecha classe
