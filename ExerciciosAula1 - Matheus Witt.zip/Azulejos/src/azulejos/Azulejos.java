package azulejos;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Azulejos {
    public static void main(String[] args) {
            double alturaParede;
            double larguraParede;
            double alturaAzulejo;
            double larguraAzulejo;
            double areaParede;
            double areaAzulejo;
            double totalAzulejos;
            
            Scanner scan = new Scanner(System.in);
            
            System.out.println("Digite a altura da parede: ");
            alturaParede = scan.nextDouble();
            System.out.println("Digite a largura da parede: ");
            larguraParede = scan.nextDouble();
            System.out.println("Digite a altura do azulejo: ");
            alturaAzulejo = scan.nextDouble();
            System.out.println("Digite a largura do azulejo: ");
            larguraAzulejo = scan.nextDouble();
            
            areaParede = alturaParede * larguraParede;
            areaAzulejo = alturaAzulejo * larguraAzulejo;
            totalAzulejos = areaParede / areaAzulejo;
            
            System.out.println("Informações");
            System.out.println("Area do Azulejo: " + areaAzulejo);
            System.out.println("Area da parede: " + areaParede);
            System.out.println("Total de azulejos: " + totalAzulejos);
    }//fecha main
}//fecha classe
