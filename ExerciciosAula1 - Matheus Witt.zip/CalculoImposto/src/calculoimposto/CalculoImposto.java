package calculoimposto;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class CalculoImposto {
    public static void main(String[] args) {
        double areaTotal;
        double areaConstruida;
        double valorConstruido;
        double valorNConstruido;
        double valorAPagar;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("R$ 7,50 para cada metro quadrado construído:");
        System.out.println("R$ 5,60 para cada metro quadrado não construído.");
        System.out.println("Digite a area total do terreno: ");
        areaTotal = scan.nextDouble();
        System.out.println("Digite a area construida do terreno: ");
        areaConstruida = scan.nextDouble();
        
        valorConstruido = areaConstruida * 7.50;
        valorNConstruido = (areaTotal - areaConstruida) * 5.60;
        valorAPagar = valorConstruido + valorNConstruido;
        
        System.out.println("Informações");
        System.out.println("Area total do terreno: " + areaTotal);
        System.out.println("Area construida do terreno: " + areaConstruida);
        System.out.println("Valor total a pagar: " + valorAPagar);
    }//fecha main
}//fecha classe
