package medicaoretangulo;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class MedicaoRetangulo {
    public static void main(String[] args) {
        double comprimento;
        double largura;
        double area;
        double perimetro;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Informe o comprimento do retangulo: ");
        comprimento = scan.nextDouble();
        System.out.println("Informe a altura do retangulo: ");
        largura = scan.nextDouble();
        
        area = comprimento * largura;
        perimetro = ((2*comprimento)+(2*largura));
        
        System.out.println("Informações sobre o retângulo");
        System.out.println("Comprimento do retângulo: " + comprimento);
        System.out.println("Largura do retângulo: " + largura);
        System.out.println("Area do retângulo: " + area);
        System.out.println("Perimetro do retângulo: " + perimetro);
    }//fecha main
}//fecha classe
