package conversaodolarreal;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class ConversaoDolarReal {
    public static void main(String[] args) {
          double dolar = 0;
          double cota = 0;
          double real = 0;
          Scanner scan = new Scanner(System.in);
          
          System.out.println("Dólar? ");
          dolar = scan.nextDouble();
          
          cota = 3.23;
          real = dolar * cota;
          
          System.out.println("Informações");
          System.out.println("Dólar: " + dolar);
          System.out.println("Cotação: " + cota);
          System.out.println("Real: " + real);
    }//fecha main
}//fecha classe
