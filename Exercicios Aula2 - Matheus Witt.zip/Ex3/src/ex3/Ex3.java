package ex3;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex3 {
    public static void main(String[] args) {
        int num1;
        int num2;
        int num3;
        int num4;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Digite um numero");
        num1 = scan.nextInt();
        System.out.println("Digite um segundo numero");
        num2 = scan.nextInt();
        System.out.println("Digite um terceiro numero");
        num3 = scan.nextInt();
        System.out.println("Digite um quarto numero");
        num4 = scan.nextInt();
        
        if(num1>num2 && num1>num3 && num1>num4 && num2>num3 && num2>num4 && num3>num4){
            System.out.println("Ordem crescente: \n"+num1+"\n"+num2+"\n"+num3+"\n"+num4);
        }else if(num2>num1 && num2>num3 && num2>num4 && num1>num3 && num1>4 && num3>num4){
            System.out.println("Ordem crescente: \n"+num2+"\n"+num1+"\n"+num3+"\n"+num4);
        }else if(num3>num1 && num3>num2 && num3>num4 && num4>num1 && num4>num2 && num2>num1){
            System.out.println("Ordem crescente: \n"+num3+"\n"+num4+"\n"+num2+"\n"+num1);
        }else if(num4>num1 && num4>num2 && num4>num3 && num1>num2 && num1>num3 && num2>num3){
            System.out.println("Ordem crescente: \n"+num4+"\n"+num1+"\n"+num2+"\n"+num3);
        }else if(num1>num2 && num1>num3 && num1>num4 && num3>num2 && num3>num4 && num2>num4){
            System.out.println("Ordem crescente: \n"+num1+"\n"+num3+"\n"+num2+"\n"+num4);
        }else if(num1>num2 && num1>num3 && num1>num4 && num4>num2 && num4>num3 && num2>num3){
            System.out.println("Ordem crescente: \n"+num1+"\n"+num4+"\n"+num2+"\n"+num3);
        }else if(num1>num2 && num1>num3 && num1>num4 && num4>num2 && num4>num3 && num3>num2){
            System.out.println("Ordem crescente: \n"+num1+"\n"+num4+"\n"+num3+"\n"+num2);
        }else if(num1>num2 && num1>num3 && num1>num4 && num3>num2 && num3>num4 && num4>num2){
            System.out.println("Ordem crescente: \n"+num1+"\n"+num3+"\n"+num4+"\n"+num2);
        }
    }//fecha main
}//fecha classe
