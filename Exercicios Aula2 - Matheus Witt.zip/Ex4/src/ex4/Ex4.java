package ex4;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex4 {
    public static void main(String[] args) {
        int codigo;
        double salario;
        double sal = 0;
        double salAtual = 0;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Digite o código correspondente ao cargo de um funcionario: ");
        codigo = scan.nextInt();
        System.out.println("Digite o seu salario atual");
        salario = scan.nextDouble();
        
        switch(codigo){
            case 1:
                sal = salario * 0.50;
                salAtual = sal + salario;
                System.out.println("Seu cargo: Escriturário\nValor de aumento 50%\nSeu novo salário: "+salAtual);
                break;
            case 2:
                sal = salario * 0.35;
                salAtual = sal + salario;
                System.out.println("Seu cargo: Escriturário\nValor de aumento 35%\nSeu novo salário: " + salAtual);
                break;
            case 3:
                sal = salario * 0.20;
                salAtual = sal + salario;
                System.out.println("Seu cargo: Escriturário\nValor de aumento 20%\nSeu novo salário: " + salAtual);
                break;
            case 4:
                sal = salario * 0.10;
                salAtual = sal + salario;
                System.out.println("Seu cargo: Escriturário\nValor de aumento 10%\nSeu novo salário: " + salAtual);
                break;
            case 5:
                salAtual = salario;
                System.out.println("Seu cargo: Escriturário\nValor de aumento 0%\nSalario atual: " + salAtual);
                break;
            default:
                System.out.println("Código errado");
        }
    }//fecha main
}//fecha classe
