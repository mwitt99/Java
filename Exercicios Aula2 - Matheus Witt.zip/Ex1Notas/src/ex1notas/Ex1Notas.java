package ex1notas;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex1Notas {
    public static void main(String[] args) {
        double notaTrab;
        double notaAvalSem;
        double notaExamFin;
        double media;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("---------Nota ----------Peso-");
        System.out.println("Trabalho de laboratorio--2---");
        System.out.println("--Avaliação semestral----3---");
        System.out.println("-------Exame final-------5---");
        System.out.println("Digite a nota do trabalho de laboratório");
        notaTrab = scan.nextDouble();
        System.out.println("Digite a nota da avaliação semestral");
        notaAvalSem = scan.nextDouble();
        System.out.println("Digite a nota do exame final");
        notaExamFin = scan.nextDouble();
        
        media = (((notaTrab*2)+(notaAvalSem*3)+(notaExamFin*5))/(2+3+5));
    
        if(media >= 8 || media == 10){
            System.out.printf("A sua média é: %2f e o seu conceito é: A",media);
        }else if(media >= 7 || media == 8){
            System.out.printf("A sua média é: %2f e o seu conceito é: B",media);
        }else if(media >= 6 || media == 7){
            System.out.printf("A sua média é: %2f e o seu conceito é: C",media);
        }else if(media >= 5 || media == 6){
            System.out.printf("A sua média é: %2f e o seu conceito é: D",media);
        }else if(media >= 0 || media == 5){
            System.out.printf("A sua média é:  %2f e o seu conceito é: E",media);
        }
    }//fecha main
}//fecha classe
