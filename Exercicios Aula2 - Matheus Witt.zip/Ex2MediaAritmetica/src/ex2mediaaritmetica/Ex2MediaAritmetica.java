package ex2mediaaritmetica;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex2MediaAritmetica {
    public static void main(String[] args) {
        double nota1;
        double nota2;
        double nota3;
        double media;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Digite a sua primeira nota: ");
        nota1 = scan.nextDouble();
        System.out.println("Digite a sua segunda nota: ");
        nota2 = scan.nextDouble();
        System.out.println("Digite a sua terceira nota: ");
        nota3 = scan.nextDouble();
        
        media = ((nota1+nota2+nota3)/3);
        
        if(media >=0 || media <=3){
            System.out.printf("A sua média é: %2f e você foi reprovado: ",media);    
        }else if(media >3 || media <=7){
            System.out.printf("A sua média é: %2f e você ficou para exame: ",media);
            System.out.println("Media|Mensagem");
            System.out.println("0,0-3,0|Reprovado");
            System.out.println("3,0-7,0|Exame");
            System.out.println("7,0-10,0|Aprovado");
        }else if(media >7 || media <=10){
            System.out.printf("A sua média é: %2f e você foi aprovado: ",media);
        }    
    }//fecha main
}//fecha classe