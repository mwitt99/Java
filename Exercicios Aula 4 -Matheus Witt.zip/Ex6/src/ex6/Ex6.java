package ex6;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex6 {

    public static void main(String[] args) {
        int n;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite um numero: ");
        n = scan.nextInt();

        for(int i = 1; i <= n; i++){
            for(int j = i; j <= n;j++){
                System.out.println (j + i + " = " + i*j);
            }
        }

    }//fecha main
}//fecha classe
