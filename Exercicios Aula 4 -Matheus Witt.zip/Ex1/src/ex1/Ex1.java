package ex1;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex1 {
    public static void main(String[] args) {
        posOuNeg();
    }//fecha main
    public static void posOuNeg(){
        int n;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite um número: ");
        n = scan.nextInt();
        
        if(n >= 0){
            n = 1;
            System.out.println("\n" + n);
        }else if(n < 0){
            n = 0;
            System.out.println("\n" + n);
        }
        
    }
}//fecha classe
