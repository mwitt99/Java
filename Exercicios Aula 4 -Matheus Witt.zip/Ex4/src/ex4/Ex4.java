package ex4;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex4 {
    public static void main(String[] args) {
        int valor;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite os segundos");
        valor = scan.nextInt();
        
        convert(valor);
    }//fecha main
    
    public static void convert(int valor){
        int minutos;
        int horas;
        int segundos;
        segundos = valor % 60;
        minutos = valor / 60;
        horas = minutos / 60;
        
        System.out.printf("Horas: %d e minutos %d e %d segundos",horas,minutos,segundos);
    }//fecha metodo   
}//fecha classe
