package ex2;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex2 {
    public static void main(String[] args) {
        int n,n1;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite dois numeros positivos: ");
        n = scan.nextInt();
        n1 = scan.nextInt();
        soma(n,n1);
    }//fecha main
    
    public static int soma(int n, int n1){
        int soma = 0;
        for(int i = n+1; i < n1;i++){
            System.out.println(i);
            soma += i;
        }
        System.out.println("Soma: " + soma);
        return 0;
    }//fecha metodo
}//fecha classe
