package ex3;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex3 {

    public static void main(String[] args) {
        int a, b, c;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite um numero: ");
        a = scan.nextInt();
        System.out.println("Digite um numero: ");
        b = scan.nextInt();
        System.out.println("Digite um numero: ");
        c = scan.nextInt();

        soma(a, b, c);
    }//fecha main

    public static int soma(int a, int b, int c) {
        int soma = 0;
        if (a > 1) {
            for (int i = b; i <= c; i++) {
                if (i % a == 0){
                    soma += i;
                }
            }
            System.out.println("Soma: " + soma);
        }
        return 0;
    }//fecha metodo
}//fecha classe