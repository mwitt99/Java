package ex5;

import java.util.Scanner;

/**
 *
 * @author Matheus Witt
 */
public class Ex5 {
    public static void main(String[] args) {
        int antigo,atual;
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o valor antigo do produto: ");
        antigo = scan.nextInt();
        System.out.println("Digie o valor atual do produto: ");
        atual = scan.nextInt();
        
        System.out.println(calculo(antigo,atual));
    }//fecha main
    
    public static int calculo(int antigo, int atual){
        return (((atual - antigo)/antigo) * 100);
    }//fecha metodo
}//fecha classe
