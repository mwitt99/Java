/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.Scanner;

/**
 *
 * @author Lab-xx-xx
 */
public class Ex3 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int vet[] = new int[10];
        int vet1[] = new int[10];
        int comp[] = new int[20];
        
        for (int i = 0; i < 9; i++) {
            System.out.println("Digite " + i + "º numero do vetor1: ");
            vet[i] = scan.nextInt();
            System.out.println("Digite " + i + "º numero do vetor2: ");
            vet1[i] = scan.nextInt();
        }
        
        for (int i = 0; i < 19; i++) {
            System.out.println(comp[i]);
        }

    }//fecha main
}//fecha classe
