/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.util.Scanner;

/**
 *
 * @author Lab-xx-xx
 */
public class Ex2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int qtdVendidos[] = new int[2];
        double valor[] = new double[2];
        double total[] = new double[2];
        double salario = 545.00;
        double comissao = 0;
        double totalvendas = 0;
        int maior = 0;
        double valorObjeto =0;
               
        
        for(int i = 0; i < 2; i++){
            System.out.println("Digite a quantidade" + i);
            qtdVendidos[i] = scan.nextInt();
            System.out.println("Digite o valor unitario" + i);
            valor[i] = scan.nextDouble();
            
            
            total[i] = qtdVendidos[i] * valor[i];
            totalvendas = totalvendas + total[i];
            comissao = comissao + total[i];
            comissao = comissao * 0.05;
            salario = salario + comissao;
            
            
        }//fecha for
        for(int i = 0; i < 2; i++){
            if(maior > qtdVendidos[i]){
                maior = qtdVendidos[i];
            }
        }
        
        valorObjeto =  valor[maior];
        for(int i = 0; i < 2; i++){
            System.out.println("Relatorio");
            System.out.println("Quantidade vendida: " + qtdVendidos[i]);
            System.out.println("Valor unitario: " + valor[i]);
            System.out.println("Valor de cada objeto: " + total[i]);
            System.out.println("Valor geral das vendas: " + totalvendas);
            System.out.println("Valor da comissao: " + comissao);
            System.out.println("Valor do objeto mais vendido: " + valorObjeto);
        }
    }//fecha main
}//fecha classe
