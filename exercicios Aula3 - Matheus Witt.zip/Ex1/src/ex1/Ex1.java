/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Scanner;

/**
 *
 * @author Lab-xx-xx
 */
public class Ex1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int vet[] = new int[9];
        
        for(int i = 0; i<9;i++){
            System.out.println("Digite numeros inteiros" + i);
            vet[i] = scan.nextInt();
            
            
        }//fecha for
        for(int i = 0; i<9;i++){
            if(vet[i] % 2 == 1){
                System.out.println("Resultado: " + vet[i]);
            }
        }
    }//fecha main
}//fecha classe
