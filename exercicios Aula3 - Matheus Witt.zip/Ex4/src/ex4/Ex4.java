/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

import java.util.Scanner;

/**
 *
 * @author Lab-xx-xx
 */
public class Ex4 {
    public static void main(String[] args) {
        int x[][] = new int [2][2];
        int y[][] = new int [2][2];
        int maior=0; 
        Scanner scan = new Scanner(System.in);
        
        for(int i = 0;i<2;i++){
            for(int j = 0;j<2;j++){
                System.out.println("Digite um numero");
                x[i][j] = scan.nextInt();
                
                if(x[i][j] > maior){
                    maior = x[i][j];
                }
            }//fecha for
        }//fecha for
        System.out.println(maior);
    }//fecha main
}//fecha classe
